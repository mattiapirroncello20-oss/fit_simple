import 'package:flutter/material.dart';
import '../core/models.dart';
import '../services/health_service.dart';
import '../services/plan_engine.dart';
import '../services/storage.dart';

/// Stato globale dell'app (Provider + ChangeNotifier). Semplice e leggero.
class AppState extends ChangeNotifier {
  final _health = HealthService();

  bool loading = true;
  Profile? profile;
  List<Entry> entries = [];
  ThemeMode themeMode = ThemeMode.system;
  int stepGoal = 8000;
  bool healthConnected = false;

  /// Passi degli ultimi 14 giorni, dal più vecchio (indice 0) a oggi (indice 13).
  List<int> steps14 = List.filled(14, 0);

  int get todaySteps => steps14.last;

  /// Peso corrente = ultima misura; se manca, quello dichiarato nel profilo.
  /// Piano e dieta dipendono da questo valore, quindi si rigenerano da soli.
  double get weight => latest(MetricType.weight)?.value ?? profile?.weightKg ?? 70;

  List<String> get tips =>
      PlanEngine.tips(profile!, stepGoal, steps14, of(MetricType.weight));

  Future<void> init() async {
    profile = Storage.loadProfile();
    entries = Storage.loadEntries();
    themeMode = ThemeMode.values[Storage.themeIndex.clamp(0, 2)];
    stepGoal = Storage.stepGoal;
    healthConnected = Storage.healthOn;
    loading = false;
    notifyListeners();
    await refreshSteps();
  }

  // ---------- Misure ----------

  List<Entry> of(MetricType t) =>
      entries.where((e) => e.type == t).toList()..sort((a, b) => a.date.compareTo(b.date));

  Entry? latest(MetricType t) {
    final l = of(t);
    return l.isEmpty ? null : l.last;
  }

  Future<void> addEntry(Entry e) async {
    entries = [...entries, e];
    await Storage.saveEntries(entries);
    if (e.type == MetricType.steps) {
      await refreshSteps();
    } else {
      notifyListeners();
    }
  }

  Future<void> deleteEntry(Entry e) async {
    entries = entries.where((x) => !identical(x, e)).toList();
    await Storage.saveEntries(entries);
    if (e.type == MetricType.steps) {
      await refreshSteps();
    } else {
      notifyListeners();
    }
  }

  // ---------- Profilo e impostazioni ----------

  Future<void> saveProfile(Profile p) async {
    final weightChanged = profile == null || (p.weightKg - weight).abs() > 0.05;
    profile = p;
    await Storage.saveProfile(p);
    if (weightChanged) {
      // Il nuovo peso diventa anche un punto del grafico.
      await addEntry(Entry(MetricType.weight, DateTime.now(), p.weightKg));
    } else {
      notifyListeners();
    }
  }

  Future<void> setTheme(ThemeMode m) async {
    themeMode = m;
    await Storage.setThemeIndex(m.index);
    notifyListeners();
  }

  Future<void> setStepGoal(int v) async {
    stepGoal = v;
    await Storage.setStepGoal(v);
    notifyListeners();
  }

  // ---------- Passi ----------

  Future<bool> connectHealth() async {
    final ok = await _health.request();
    healthConnected = ok;
    await Storage.setHealthOn(ok);
    await refreshSteps();
    return ok;
  }

  Future<void> refreshSteps() async {
    final t = DateTime.now();
    final days = [for (var i = 13; i >= 0; i--) DateTime(t.year, t.month, t.day - i)];
    if (healthConnected) {
      steps14 = await Future.wait(days.map(_health.steps));
    } else {
      // Senza Health: usa i passi inseriti a mano.
      steps14 = days.map(_manualSteps).toList();
    }
    notifyListeners();
  }

  int _manualSteps(DateTime d) {
    final l = of(MetricType.steps).where((e) => dayOf(e.date) == d);
    return l.isEmpty ? 0 : l.last.value.round();
  }
}
