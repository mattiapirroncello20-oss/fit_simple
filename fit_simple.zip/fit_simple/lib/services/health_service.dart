import 'package:health/health.dart';

/// Lettura passi da Health Connect (Android) e HealthKit (iOS).
/// Solo lettura: l'app non scrive mai dati di salute.
class HealthService {
  final Health _h = Health();
  bool _configured = false;

  static const _types = [HealthDataType.STEPS];
  static const _perms = [HealthDataAccess.READ];

  Future<void> _cfg() async {
    if (!_configured) {
      await _h.configure();
      _configured = true;
    }
  }

  /// Mostra la schermata di sistema per i permessi. Ritorna true se concessi.
  Future<bool> request() async {
    try {
      await _cfg();
      return await _h.requestAuthorization(_types, permissions: _perms);
    } catch (_) {
      return false;
    }
  }

  /// Passi totali di un giorno (per oggi: fino ad ora). 0 in caso di errore.
  Future<int> steps(DateTime day) async {
    try {
      await _cfg();
      final start = DateTime(day.year, day.month, day.day);
      final now = DateTime.now();
      var end = start.add(const Duration(days: 1));
      if (end.isAfter(now)) end = now;
      return await _h.getTotalStepsInInterval(start, end) ?? 0;
    } catch (_) {
      return 0;
    }
  }
}
