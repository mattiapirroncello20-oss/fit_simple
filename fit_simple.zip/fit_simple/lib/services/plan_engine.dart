import 'dart:math';
import '../core/models.dart';

// "IA" locale basata su regole: deterministica, offline, nessun dato lascia il telefono.
// Il piano è una funzione pura di (profilo, peso corrente): cambia peso/obiettivo -> si rigenera.

class Macros {
  final int kcal, protein, carbs, fat;
  const Macros(this.kcal, this.protein, this.carbs, this.fat);
}

class Exercise {
  final String name, detail;
  const Exercise(this.name, this.detail);
}

class WorkoutDay {
  final String title;
  final List<Exercise> exercises;
  const WorkoutDay(this.title, this.exercises);
}

class Meal {
  final String name, example;
  final int kcal;
  const Meal(this.name, this.kcal, this.example);
}

class _Food {
  final String name;
  final List<String> tags;
  const _Food(this.name, [this.tags = const []]);
}

class PlanEngine {
  // ---------- Fabbisogno ----------

  /// Mifflin-St Jeor. Per "Altro" si usa la media dei due termini costanti (-78).
  static double bmr(Profile p, double w) =>
      10 * w +
      6.25 * p.heightCm -
      5 * p.age +
      (switch (p.sex) { Sex.male => 5.0, Sex.female => -161.0, Sex.other => -78.0 });

  static double tdee(Profile p, double w) => bmr(p, w) * p.activity.factor;

  static Macros macros(Profile p, double w) {
    final mult = switch (p.goal) {
      Goal.lose => 0.85, // deficit moderato ~15%
      Goal.gain => 1.10, // surplus lieve ~10%
      Goal.maintain => 1.0,
    };
    // Soglia di sicurezza: mai sotto 1500 (uomo) / 1200 (donna e altro) kcal.
    final floor = p.sex == Sex.male ? 1500.0 : 1200.0;
    final kcal = max(tdee(p, w) * mult, floor);
    final proteinPerKg = switch (p.goal) {
      Goal.lose => 2.0,
      Goal.gain => 1.8,
      Goal.maintain => 1.6,
    };
    final protein = w * proteinPerKg;
    final fat = kcal * 0.25 / 9;
    final carbs = max(0.0, (kcal - protein * 4 - fat * 9) / 4);
    return Macros(kcal.round(), protein.round(), carbs.round(), fat.round());
  }

  /// Stima grossolana: ~0,04 kcal per passo per una persona di 70 kg (scala col peso).
  static int stepKcal(int steps, double w) => (steps * w * 0.00057).round();

  // ---------- Allenamento ----------

  static const _legs = ['Squat (o goblet squat)', 'Affondi alternati', 'Stacco rumeno', 'Hip thrust'];
  static const _push = ['Panca piana (o push-up)', 'Military press', 'Alzate laterali', 'French press / dip su panca'];
  static const _pull = ['Lat machine (o trazioni)', 'Rematore con manubrio', 'Face pull', 'Curl bicipiti'];
  static const _core = ['Plank', 'Crunch inverso', 'Russian twist'];

  static List<WorkoutDay> workout(Profile p) {
    final level = switch (p.activity) {
      Activity.sedentary || Activity.light => 0,
      Activity.moderate => 1,
      Activity.intense => 2,
    };
    final sets = level == 2 ? 4 : 3;
    final reps = switch (p.goal) {
      Goal.lose => '12–15',
      Goal.gain => level == 0 ? '8–12' : '6–10',
      Goal.maintain => '10–12',
    };
    final rest = switch (p.goal) { Goal.lose => 45, Goal.gain => 90, Goal.maintain => 60 };

    Exercise ex(String n) => Exercise(n, '$sets × $reps · rec. ${rest}s');
    List<Exercise> pick(List<String> pool, int n, int k) =>
        [for (var i = 0; i < n; i++) ex(pool[(k + i) % pool.length])];
    final cardio = p.goal == Goal.lose
        ? [const Exercise('Cardio leggero', '15–20 min')]
        : <Exercise>[];
    WorkoutDay day(String title, List<Exercise> e, int k) => WorkoutDay(
        title, [...e, Exercise(_core[k % _core.length], '3 × 30–45 s'), ...cardio]);

    WorkoutDay upper(int k) => day('Upper body', [...pick(_push, 2, k), ...pick(_pull, 2, k)], k);
    WorkoutDay lower(int k) => day('Lower body', pick(_legs, 4, k), k);
    WorkoutDay push(int k) => day('Push', pick(_push, 4, k), k);
    WorkoutDay pull(int k) => day('Pull', pick(_pull, 4, k), k);
    WorkoutDay legs(int k) => day('Gambe', pick(_legs, 4, k), k);

    final d = p.daysPerWeek.clamp(1, 6);
    if (d <= 3) {
      return [
        for (var k = 0; k < d; k++)
          day('Full body ${'ABC'[k]}',
              [...pick(_legs, 2, k), ...pick(_push, 1, k), ...pick(_pull, 1, k)], k)
      ];
    }
    if (d == 4) return [upper(0), lower(0), upper(1), lower(1)];
    if (d == 5) return [push(0), pull(0), legs(0), upper(1), lower(1)];
    return [push(0), pull(0), legs(0), push(1), pull(1), legs(1)];
  }

  // ---------- Dieta ----------

  static Set<String> _exclusions(String prefs) {
    final t = prefs.toLowerCase();
    final ex = <String>{};
    if (t.contains('vegan')) ex.addAll(['carne', 'pesce', 'latticini', 'uova']);
    if (t.contains('vegetarian')) ex.addAll(['carne', 'pesce']);
    if (t.contains('lattosio') || t.contains('latticin')) ex.add('latticini');
    if (t.contains('glutine') || t.contains('celiac')) ex.add('glutine');
    if (t.contains('pesce')) ex.add('pesce');
    if (t.contains('carne')) ex.add('carne');
    if (t.contains('uova')) ex.add('uova');
    if (t.contains('noci') || t.contains('frutta secca') || t.contains('mandorle')) {
      ex.add('fruttasecca');
    }
    if (t.contains('arachid')) ex.add('arachidi');
    return ex;
  }

  // L'ultima opzione di ogni lista è sempre priva di allergeni (fallback).
  static const _breakfast = [
    _Food('Yogurt greco, fiocchi di avena e frutta', ['latticini', 'glutine']),
    _Food('Pane integrale con uova e avocado', ['glutine', 'uova']),
    _Food('Porridge di avena con bevanda vegetale e frutta', ['glutine']),
    _Food('Frutta fresca con riso soffiato'),
  ];
  static const _lunch = [
    _Food('Riso con pollo e verdure', ['carne']),
    _Food('Pasta integrale con tonno e pomodorini', ['glutine', 'pesce']),
    _Food('Pasta con lenticchie e verdure', ['glutine']),
    _Food('Riso con legumi e verdure'),
  ];
  static const _snack = [
    _Food('Frutta e mandorle', ['fruttasecca']),
    _Food('Yogurt con miele', ['latticini']),
    _Food('Hummus con bastoncini di verdura'),
  ];
  static const _dinner = [
    _Food('Salmone al forno con patate e insalata', ['pesce']),
    _Food('Frittata di verdure con pane', ['uova', 'glutine']),
    _Food('Petto di tacchino con patate e verdure', ['carne']),
    _Food('Legumi e verdure con patate'),
  ];

  static List<Meal> meals(Profile p, Macros m) {
    final ex = _exclusions(p.prefs);
    Meal build(String name, double share, List<_Food> opts) {
      final f = opts.firstWhere((o) => !o.tags.any(ex.contains), orElse: () => opts.last);
      return Meal(name, (m.kcal * share).round(), f.name);
    }

    return [
      build('Colazione', 0.25, _breakfast),
      build('Pranzo', 0.35, _lunch),
      build('Spuntino', 0.10, _snack),
      build('Cena', 0.30, _dinner),
    ];
  }

  // ---------- Consigli brevi ----------

  /// [steps14]: ultimi 14 giorni (vecchio -> nuovo). [weights]: misure peso ordinate per data.
  static List<String> tips(Profile p, int goal, List<int> steps14, List<Entry> weights) {
    final out = <String>[];
    final cur = steps14.sublist(7), prev = steps14.sublist(0, 7);
    final avg = cur.reduce((a, b) => a + b) / 7;
    final prevAvg = prev.reduce((a, b) => a + b) / 7;

    if (avg > 0) {
      if (prevAvg > 0 && avg < prevAvg * 0.85) {
        final pct = ((1 - avg / prevAvg) * 100).round();
        out.add('Hai fatto meno passi del solito questa settimana (−$pct%). '
            'Prova una camminata di 15 minuti dopo i pasti.');
      } else if (avg >= goal) {
        out.add('Ottimo: la media settimanale supera il tuo obiettivo. '
            "Se ti senti bene, puoi alzarlo un po'.");
      } else if (avg < goal * 0.7) {
        out.add('Media settimanale: ${fmt(avg.round())} passi, sotto il tuo obiettivo. '
            'Piccoli extra (scale, pausa a piedi) fanno la differenza.');
      }
    }

    final cutoff = DateTime.now().subtract(const Duration(days: 28));
    final recent = weights.where((e) => e.date.isAfter(cutoff)).toList();
    if (recent.length >= 2 && recent.last.date.difference(recent.first.date).inDays >= 7) {
      final delta = recent.last.value - recent.first.value;
      final weeks = recent.last.date.difference(recent.first.date).inDays / 7;
      final perWeek = delta / weeks;
      if (p.goal == Goal.lose && delta >= 0) {
        out.add('Il peso non sta scendendo: controlla le porzioni e prova ad aumentare i passi.');
      } else if (p.goal == Goal.lose && perWeek < -0.01 * recent.last.value) {
        out.add('Stai perdendo peso molto in fretta: assicurati di mangiare abbastanza.');
      } else if (p.goal == Goal.gain && delta <= 0) {
        out.add('Il peso non sale: aggiungi uno spuntino da circa 150–200 kcal.');
      } else {
        out.add('Andamento del peso in linea con il tuo obiettivo. Continua così.');
      }
    }

    if (out.isEmpty) {
      out.add('Registra il peso una volta a settimana per ricevere consigli più precisi.');
    }
    return out.take(3).toList();
  }
}
