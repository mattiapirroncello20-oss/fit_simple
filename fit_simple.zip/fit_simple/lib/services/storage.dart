import 'package:hive_flutter/hive_flutter.dart';
import '../core/models.dart';

/// Persistenza locale con Hive: un unico box, nessun server, funziona offline.
class Storage {
  static late Box _box;

  static Future<void> init() async {
    await Hive.initFlutter();
    _box = await Hive.openBox('fit_simple');
  }

  static Profile? loadProfile() {
    final m = _box.get('profile');
    return m == null ? null : Profile.fromMap(Map<String, dynamic>.from(m as Map));
  }

  static Future<void> saveProfile(Profile p) => _box.put('profile', p.toMap());

  static List<Entry> loadEntries() {
    final list = (_box.get('entries', defaultValue: []) as List);
    return list
        .map((e) => Entry.fromMap(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  static Future<void> saveEntries(List<Entry> e) =>
      _box.put('entries', e.map((x) => x.toMap()).toList());

  static int get themeIndex => _box.get('theme', defaultValue: 0) as int;
  static Future<void> setThemeIndex(int i) => _box.put('theme', i);

  static int get stepGoal => _box.get('stepGoal', defaultValue: 8000) as int;
  static Future<void> setStepGoal(int v) => _box.put('stepGoal', v);

  /// true se l'utente ha già concesso l'accesso a Health Connect / HealthKit.
  static bool get healthOn => _box.get('healthOn', defaultValue: false) as bool;
  static Future<void> setHealthOn(bool v) => _box.put('healthOn', v);
}
