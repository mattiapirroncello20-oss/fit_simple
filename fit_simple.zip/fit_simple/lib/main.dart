import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter_displaymode/flutter_displaymode.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'services/storage.dart';
import 'state/app_state.dart';
import 'ui/main_shell.dart';
import 'ui/onboarding.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Storage.init();

  // Android: chiede al sistema la modalità a refresh rate più alto (90/120Hz).
  // Su iOS (ProMotion) basta la chiave CADisableMinimumFrameDurationOnPhone in Info.plist.
  if (Platform.isAndroid) {
    try {
      await FlutterDisplayMode.setHighRefreshRate();
    } catch (_) {/* dispositivo senza modalità multiple: ignora */}
  }

  runApp(ChangeNotifierProvider(
    create: (_) => AppState()..init(),
    child: const FitApp(),
  ));
}

class FitApp extends StatelessWidget {
  const FitApp({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return MaterialApp(
      title: 'Fit Simple',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: s.themeMode,
      home: s.loading
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : s.profile == null
              ? const OnboardingScreen()
              : const MainShell(),
    );
  }
}
