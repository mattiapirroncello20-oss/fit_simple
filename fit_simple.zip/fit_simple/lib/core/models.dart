// Modelli di dominio. Tutti serializzabili in semplici Map per Hive (niente codegen).

enum Sex { male, female, other }
enum Goal { lose, gain, maintain }
enum Activity { sedentary, light, moderate, intense }
enum MetricType { weight, steps, waist, chest, hips }

extension SexX on Sex {
  String get label => switch (this) {
        Sex.male => 'Uomo',
        Sex.female => 'Donna',
        Sex.other => 'Altro',
      };
}

extension GoalX on Goal {
  String get label => switch (this) {
        Goal.lose => 'Dimagrire',
        Goal.gain => 'Massa muscolare',
        Goal.maintain => 'Mantenimento',
      };
}

extension ActivityX on Activity {
  String get label => switch (this) {
        Activity.sedentary => 'Sedentario',
        Activity.light => 'Leggero',
        Activity.moderate => 'Moderato',
        Activity.intense => 'Intenso',
      };
  String get hint => switch (this) {
        Activity.sedentary => 'Lavoro da seduto, poco movimento',
        Activity.light => 'Qualche camminata, 1–2 attività a settimana',
        Activity.moderate => 'Ti muovi o ti alleni 3–5 volte a settimana',
        Activity.intense => 'Allenamenti intensi o lavoro fisico quasi ogni giorno',
      };

  /// Moltiplicatore del metabolismo basale (livelli di attività standard).
  double get factor => switch (this) {
        Activity.sedentary => 1.2,
        Activity.light => 1.375,
        Activity.moderate => 1.55,
        Activity.intense => 1.725,
      };
}

extension MetricX on MetricType {
  String get label => switch (this) {
        MetricType.weight => 'Peso',
        MetricType.steps => 'Passi',
        MetricType.waist => 'Vita',
        MetricType.chest => 'Torace',
        MetricType.hips => 'Fianchi',
      };
  String get unit => switch (this) {
        MetricType.weight => 'kg',
        MetricType.steps => 'passi',
        _ => 'cm',
      };
}

class Profile {
  final String name;
  final int age;
  final Sex sex;
  final double heightCm;
  final double weightKg; // peso dichiarato; quello "corrente" è l'ultima misura
  final Goal goal;
  final Activity activity;
  final int daysPerWeek;
  final String prefs; // preferenze/esclusioni alimentari (testo libero)

  const Profile({
    required this.name,
    required this.age,
    required this.sex,
    required this.heightCm,
    required this.weightKg,
    required this.goal,
    required this.activity,
    required this.daysPerWeek,
    required this.prefs,
  });

  Map<String, dynamic> toMap() => {
        'name': name,
        'age': age,
        'sex': sex.index,
        'height': heightCm,
        'weight': weightKg,
        'goal': goal.index,
        'activity': activity.index,
        'days': daysPerWeek,
        'prefs': prefs,
      };

  factory Profile.fromMap(Map<String, dynamic> m) => Profile(
        name: m['name'] as String,
        age: m['age'] as int,
        sex: Sex.values[m['sex'] as int],
        heightCm: (m['height'] as num).toDouble(),
        weightKg: (m['weight'] as num).toDouble(),
        goal: Goal.values[m['goal'] as int],
        activity: Activity.values[m['activity'] as int],
        daysPerWeek: m['days'] as int,
        prefs: (m['prefs'] as String?) ?? '',
      );
}

/// Una misura inserita a mano (peso, passi, vita...).
class Entry {
  final MetricType type;
  final DateTime date;
  final double value;
  const Entry(this.type, this.date, this.value);

  Map<String, dynamic> toMap() =>
      {'t': type.index, 'd': date.toIso8601String(), 'v': value};

  factory Entry.fromMap(Map<String, dynamic> m) => Entry(
        MetricType.values[m['t'] as int],
        DateTime.parse(m['d'] as String),
        (m['v'] as num).toDouble(),
      );
}

DateTime dayOf(DateTime d) => DateTime(d.year, d.month, d.day);

String fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';

/// 12345 -> "12.345"
String fmt(int n) => n
    .toString()
    .replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '.');
