import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import 'profile_form.dart';
import 'widgets.dart';

/// Prima schermata: raccoglie i dati e crea il profilo.
class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
          children: [
            Text('Benvenuto 👋', style: t.headlineLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              'Raccontaci qualcosa di te: prepareremo una scheda di allenamento e una dieta '
              'su misura. I dati restano sul tuo telefono.',
              style: t.bodyLarge,
            ),
            const SizedBox(height: 28),
            ProfileForm(
              submitLabel: 'Inizia',
              onSubmit: (p) => context.read<AppState>().saveProfile(p),
            ),
            const Disclaimer(),
          ],
        ),
      ),
    );
  }
}
