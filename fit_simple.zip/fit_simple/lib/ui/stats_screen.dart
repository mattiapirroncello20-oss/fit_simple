import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/models.dart';
import '../state/app_state.dart';
import 'widgets.dart';

/// Peso, passi e misure inseribili a mano, con grafico nel tempo.
class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});
  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  MetricType _metric = MetricType.weight;

  Future<void> _add() async {
    final e = await showModalBottomSheet<Entry>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _AddEntrySheet(metric: _metric),
    );
    if (e != null && mounted) context.read<AppState>().addEntry(e);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;
    final data = s.of(_metric);
    final last = data.isEmpty ? null : data.last;
    final diff = data.length >= 2 ? data.last.value - data.first.value : null;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _add,
          icon: const Icon(Icons.add),
          label: Text('Aggiungi ${_metric.label.toLowerCase()}'),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
          children: [
            Text('Statistiche', style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            Wrap(spacing: 8, children: [
              for (final m in MetricType.values)
                ChoiceChip(
                  label: Text(m.label),
                  selected: m == _metric,
                  onSelected: (_) => setState(() => _metric = m),
                ),
            ]),
            const SizedBox(height: 16),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  last == null ? '—' : '${_fmtVal(last.value)} ${_metric.unit}',
                  style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w700),
                ),
                if (diff != null)
                  Text(
                    '${diff >= 0 ? '+' : ''}${_fmtVal(diff)} ${_metric.unit} dalla prima misura',
                    style: t.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                  ),
                const SizedBox(height: 16),
                _chart(context, data),
              ]),
            ),
            const SectionTitle('Storico'),
            if (data.isEmpty)
              Text('Nessuna misura. Tocca "Aggiungi" per iniziare.', style: t.bodyMedium),
            for (final e in data.reversed)
              Dismissible(
                key: ObjectKey(e),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: Icon(Icons.delete_outline, color: cs.error),
                ),
                onDismissed: (_) => context.read<AppState>().deleteEntry(e),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                  title: Text('${_fmtVal(e.value)} ${_metric.unit}'),
                  trailing: Text(fmtDate(e.date), style: t.bodySmall),
                ),
              ),
            if (data.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('Scorri a sinistra per eliminare una misura.', style: t.bodySmall),
              ),
          ],
        ),
      ),
    );
  }

  String _fmtVal(double v) => _metric == MetricType.steps ? fmt(v.round()) : v.toStringAsFixed(1);

  Widget _chart(BuildContext context, List<Entry> data) {
    final cs = Theme.of(context).colorScheme;
    if (data.length < 2) {
      return const SizedBox(
        height: 140,
        child: Center(child: Text('Servono almeno 2 misure per vedere il grafico')),
      );
    }
    final pts = data.length > 30 ? data.sublist(data.length - 30) : data;
    final first = pts.first.date;
    final spots = [
      for (final e in pts) FlSpot(e.date.difference(first).inHours / 24.0, e.value)
    ];
    final ys = pts.map((e) => e.value);
    final lo = ys.reduce(min), hi = ys.reduce(max);
    final pad = max((hi - lo) * 0.2, 1.0);
    final range = hi - lo + 2 * pad;
    return SizedBox(
      height: 200,
      child: RepaintBoundary(
        child: LineChart(LineChartData(
          minY: lo - pad,
          maxY: hi + pad,
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          lineTouchData: const LineTouchData(enabled: false),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 44,
                interval: range / 4,
                getTitlesWidget: (v, _) => Text(
                  _metric == MetricType.steps ? fmt(v.round()) : v.toStringAsFixed(0),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              barWidth: 3,
              color: cs.primary,
              dotData: const FlDotData(show: true),
              belowBarData: BarAreaData(show: true, color: cs.primary.withValues(alpha: 0.08)),
            ),
          ],
        )),
      ),
    );
  }
}

class _AddEntrySheet extends StatefulWidget {
  final MetricType metric;
  const _AddEntrySheet({required this.metric});
  @override
  State<_AddEntrySheet> createState() => _AddEntrySheetState();
}

class _AddEntrySheetState extends State<_AddEntrySheet> {
  final _ctrl = TextEditingController();
  DateTime _date = DateTime.now();
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _save() {
    final v = double.tryParse(_ctrl.text.trim().replaceAll(',', '.'));
    if (v == null || v <= 0) {
      setState(() => _error = 'Inserisci un numero valido');
      return;
    }
    Navigator.pop(context, Entry(widget.metric, _date, v));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(24, 0, 24, 24 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Nuova misura: ${widget.metric.label}', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 16),
        TextField(
          controller: _ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: widget.metric.unit, errorText: _error),
          onSubmitted: (_) => _save(),
        ),
        const SizedBox(height: 8),
        TextButton.icon(
          icon: const Icon(Icons.calendar_today_outlined, size: 18),
          label: Text('Data: ${fmtDate(_date)}'),
          onPressed: () async {
            final d = await showDatePicker(
              context: context,
              initialDate: _date,
              firstDate: DateTime(2020),
              lastDate: DateTime.now(),
            );
            if (d != null) setState(() => _date = d);
          },
        ),
        const SizedBox(height: 8),
        FilledButton(onPressed: _save, child: const Text('Salva')),
      ]),
    );
  }
}
