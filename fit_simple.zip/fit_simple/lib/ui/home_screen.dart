import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/models.dart';
import '../services/plan_engine.dart';
import '../state/app_state.dart';
import 'widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.profile!;
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;
    final m = PlanEngine.macros(p, s.weight);
    final burned = PlanEngine.stepKcal(s.todaySteps, s.weight);

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: s.refreshSteps,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            Text('Ciao, ${p.name}', style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
            Text('Ecco la tua giornata', style: t.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
            const SizedBox(height: 24),
            Center(child: StepRing(steps: s.todaySteps, goal: s.stepGoal)),
            const SizedBox(height: 24),
            Row(children: [
              _Stat('Obiettivo', '${fmt(s.stepGoal)} passi'),
              const SizedBox(width: 10),
              _Stat('Passi → kcal', '≈ $burned'),
              const SizedBox(width: 10),
              _Stat('Fabbisogno', '${m.kcal} kcal'),
            ]),
            if (!s.healthConnected) ...[
              const SizedBox(height: 16),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Collega il contapassi', style: t.titleSmall),
                  const SizedBox(height: 4),
                  Text(
                    'Concedi la lettura dei passi da Health Connect (Android) o Salute (iOS). '
                    'I dati restano sul telefono. Intanto puoi inserirli a mano in Statistiche.',
                    style: t.bodySmall,
                  ),
                  const SizedBox(height: 12),
                  FilledButton.tonal(
                    onPressed: () async {
                      final ok = await context.read<AppState>().connectHealth();
                      if (!ok && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('Permesso non concesso o Health non disponibile.')));
                      }
                    },
                    child: const Text('Collega'),
                  ),
                ]),
              ),
            ],
            const SectionTitle('Ultimi 7 giorni'),
            AppCard(child: _WeekChart(steps: s.steps14.sublist(7), goal: s.stepGoal)),
            const SectionTitle('Consigli per te'),
            for (final tip in s.tips)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: AppCard(
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Icon(Icons.lightbulb_outline, size: 20, color: cs.primary),
                    const SizedBox(width: 12),
                    Expanded(child: Text(tip, style: t.bodyMedium)),
                  ]),
                ),
              ),
            const Disclaimer(),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label, value;
  const _Stat(this.label, this.value);
  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Expanded(
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: t.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 4),
          Text(value, style: t.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

/// Grafico a barre dei passi della settimana, con linea tratteggiata sull'obiettivo.
class _WeekChart extends StatelessWidget {
  final List<int> steps; // 7 valori, l'ultimo è oggi
  final int goal;
  const _WeekChart({required this.steps, required this.goal});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const letters = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
    final now = DateTime.now();
    final maxY = max(goal, steps.reduce(max)) * 1.15;
    return SizedBox(
      height: 180,
      child: RepaintBoundary(
        child: BarChart(BarChartData(
          maxY: maxY,
          barTouchData: BarTouchData(enabled: false),
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (v, _) {
                  final d = DateTime(now.year, now.month, now.day - (6 - v.toInt()));
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(letters[d.weekday - 1],
                        style: Theme.of(context).textTheme.bodySmall),
                  );
                },
              ),
            ),
          ),
          extraLinesData: ExtraLinesData(horizontalLines: [
            HorizontalLine(y: goal.toDouble(), color: cs.outline, strokeWidth: 1, dashArray: [4, 4]),
          ]),
          barGroups: [
            for (var i = 0; i < steps.length; i++)
              BarChartGroupData(x: i, barRods: [
                BarChartRodData(
                  toY: steps[i].toDouble(),
                  width: 18,
                  color: steps[i] >= goal ? cs.primary : cs.primary.withValues(alpha: 0.45),
                  borderRadius: BorderRadius.circular(6),
                ),
              ]),
          ],
        )),
      ),
    );
  }
}
