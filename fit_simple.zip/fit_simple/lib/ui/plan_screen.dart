import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/plan_engine.dart';
import '../state/app_state.dart';
import 'widgets.dart';

/// Scheda allenamento + dieta. Entrambe sono calcolate al volo da profilo e peso
/// corrente, quindi si aggiornano automaticamente quando cambiano peso o obiettivo.
class PlanScreen extends StatefulWidget {
  const PlanScreen({super.key});
  @override
  State<PlanScreen> createState() => _PlanScreenState();
}

class _PlanScreenState extends State<PlanScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = s.profile!;
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;
    final macros = PlanEngine.macros(p, s.weight);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          Text('Il tuo piano', style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
          Text('Obiettivo: ${p.goal.label} · ${s.weight.toStringAsFixed(1)} kg',
              style: t.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
          const SizedBox(height: 16),
          SegmentedButton<int>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 0, label: Text('Allenamento'), icon: Icon(Icons.fitness_center)),
              ButtonSegment(value: 1, label: Text('Dieta'), icon: Icon(Icons.restaurant_outlined)),
            ],
            selected: {_tab},
            onSelectionChanged: (v) => setState(() => _tab = v.first),
          ),
          const SizedBox(height: 8),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            child: _tab == 0
                ? _Workout(key: const ValueKey('w'), days: PlanEngine.workout(p))
                : _Diet(key: const ValueKey('d'), macros: macros, meals: PlanEngine.meals(p, macros)),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text('Il piano si aggiorna da solo quando cambiano peso o obiettivo.',
                style: t.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          ),
          const Disclaimer(),
        ],
      ),
    );
  }
}

class _Workout extends StatelessWidget {
  final List<WorkoutDay> days;
  const _Workout({super.key, required this.days});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('Settimana tipo'),
      for (var i = 0; i < days.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AppCard(
            padding: EdgeInsets.zero,
            child: Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                initiallyExpanded: i == 0,
                tilePadding: const EdgeInsets.symmetric(horizontal: 16),
                title: Text('Giorno ${i + 1} · ${days[i].title}',
                    style: t.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
                subtitle: Text('${days[i].exercises.length} esercizi'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                children: [
                  for (final e in days[i].exercises)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text(e.name),
                      trailing: Text(e.detail, style: t.bodySmall),
                    ),
                ],
              ),
            ),
          ),
        ),
      Text(
        'Nei giorni liberi: riposo o camminata. Scalda 5–10 minuti prima di iniziare e '
        'scegli carichi con cui chiudi ogni serie con 1–2 ripetizioni di margine.',
        style: t.bodySmall,
      ),
    ]);
  }
}

class _Diet extends StatelessWidget {
  final Macros macros;
  final List<Meal> meals;
  const _Diet({super.key, required this.macros, required this.meals});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;
    Widget macro(String l, String v) => Expanded(
          child: Column(children: [
            Text(v, style: t.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            Text(l, style: t.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          ]),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('Fabbisogno giornaliero'),
      AppCard(
        child: Column(children: [
          Text('${macros.kcal} kcal',
              style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          Row(children: [
            macro('Proteine', '${macros.protein} g'),
            macro('Carboidrati', '${macros.carbs} g'),
            macro('Grassi', '${macros.fat} g'),
          ]),
        ]),
      ),
      const SectionTitle('Esempio di giornata'),
      for (final m in meals)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AppCard(
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(m.name, style: t.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(m.example, style: t.bodyMedium),
                ]),
              ),
              Text('≈ ${m.kcal} kcal', style: t.bodySmall),
            ]),
          ),
        ),
      Text(
        'Le porzioni vanno adattate alle kcal indicate per ogni pasto. '
        'Le esclusioni che hai scritto nel profilo sono già considerate.',
        style: t.bodySmall,
      ),
    ]);
  }
}
