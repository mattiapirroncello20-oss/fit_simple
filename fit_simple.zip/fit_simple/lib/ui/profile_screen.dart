import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/models.dart';
import '../state/app_state.dart';
import 'profile_form.dart';
import 'widgets.dart';

/// Modifica dati, obiettivo passi e tema chiaro/scuro.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = Theme.of(context).textTheme;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        children: [
          Text('Profilo', style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
          const SectionTitle('Impostazioni'),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Obiettivo passi: ${fmt(s.stepGoal)}', style: t.titleSmall),
              Slider(
                value: s.stepGoal.toDouble(),
                min: 3000,
                max: 20000,
                divisions: 34, // passi da 500
                label: fmt(s.stepGoal),
                onChanged: (v) => context.read<AppState>().setStepGoal(v.round()),
              ),
              const SizedBox(height: 8),
              Text('Tema', style: t.titleSmall),
              const SizedBox(height: 8),
              SegmentedButton<ThemeMode>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: ThemeMode.system, label: Text('Auto')),
                  ButtonSegment(value: ThemeMode.light, label: Text('Chiaro')),
                  ButtonSegment(value: ThemeMode.dark, label: Text('Scuro')),
                ],
                selected: {s.themeMode},
                onSelectionChanged: (v) => context.read<AppState>().setTheme(v.first),
              ),
              if (!s.healthConnected) ...[
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  icon: const Icon(Icons.link),
                  label: const Text('Collega Health / Salute'),
                  onPressed: () => context.read<AppState>().connectHealth(),
                ),
              ],
            ]),
          ),
          const SectionTitle('I tuoi dati'),
          ProfileForm(
            // La key forza il rebuild del form se cambia il peso corrente.
            key: ValueKey(s.weight),
            initial: s.profile,
            weight: s.weight,
            submitLabel: 'Salva modifiche',
            onSubmit: (p) async {
              await context.read<AppState>().saveProfile(p);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Salvato. Scheda e dieta aggiornate.')));
              }
            },
          ),
          const Disclaimer(),
        ],
      ),
    );
  }
}
