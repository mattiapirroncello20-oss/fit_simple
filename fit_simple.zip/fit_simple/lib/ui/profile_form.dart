import 'package:flutter/material.dart';
import '../core/models.dart';

/// Form riusato da Onboarding e Profilo: nome, età, sesso, altezza, peso,
/// obiettivo, attività, giorni di allenamento, preferenze alimentari.
class ProfileForm extends StatefulWidget {
  final Profile? initial;
  final double? weight; // peso corrente (ultima misura), se diverso da quello del profilo
  final String submitLabel;
  final ValueChanged<Profile> onSubmit;
  const ProfileForm({
    super.key,
    this.initial,
    this.weight,
    required this.submitLabel,
    required this.onSubmit,
  });

  @override
  State<ProfileForm> createState() => _ProfileFormState();
}

class _ProfileFormState extends State<ProfileForm> {
  final _key = GlobalKey<FormState>();
  late final TextEditingController _name, _age, _height, _weight, _prefs;
  late Sex _sex;
  late Goal _goal;
  late Activity _activity;
  late double _days;

  @override
  void initState() {
    super.initState();
    final p = widget.initial;
    final w = widget.weight ?? p?.weightKg;
    _name = TextEditingController(text: p?.name ?? '');
    _age = TextEditingController(text: p?.age.toString() ?? '');
    _height = TextEditingController(text: p == null ? '' : p.heightCm.round().toString());
    _weight = TextEditingController(text: w == null ? '' : w.toStringAsFixed(1));
    _prefs = TextEditingController(text: p?.prefs ?? '');
    _sex = p?.sex ?? Sex.male;
    _goal = p?.goal ?? Goal.maintain;
    _activity = p?.activity ?? Activity.light;
    _days = (p?.daysPerWeek ?? 3).toDouble();
  }

  @override
  void dispose() {
    for (final c in [_name, _age, _height, _weight, _prefs]) {
      c.dispose();
    }
    super.dispose();
  }

  double? _num(String? v) => double.tryParse((v ?? '').trim().replaceAll(',', '.'));

  String? Function(String?) _range(double lo, double hi, String what) => (v) {
        final n = _num(v);
        return (n == null || n < lo || n > hi) ? '$what: valore tra ${lo.round()} e ${hi.round()}' : null;
      };

  void _submit() {
    if (!_key.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    widget.onSubmit(Profile(
      name: _name.text.trim(),
      age: _num(_age.text)!.round(),
      sex: _sex,
      heightCm: _num(_height.text)!,
      weightKg: _num(_weight.text)!,
      goal: _goal,
      activity: _activity,
      daysPerWeek: _days.round(),
      prefs: _prefs.text.trim(),
    ));
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(t, style: Theme.of(context).textTheme.titleSmall),
      );

  Widget _chips<T>(List<T> values, T sel, String Function(T) label, ValueChanged<T> on) =>
      Wrap(spacing: 8, runSpacing: 4, children: [
        for (final v in values)
          ChoiceChip(label: Text(label(v)), selected: v == sel, onSelected: (_) => setState(() => on(v))),
      ]);

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _key,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextFormField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Nome'),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'Inserisci il tuo nome' : null,
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: TextFormField(
              controller: _age,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Età'),
              validator: _range(18, 99, 'Età (app per adulti)'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextFormField(
              controller: _height,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Altezza (cm)'),
              validator: _range(120, 230, 'Altezza'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextFormField(
              controller: _weight,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Peso (kg)'),
              validator: _range(30, 250, 'Peso'),
            ),
          ),
        ]),
        _label('Sesso (serve per il calcolo del fabbisogno)'),
        _chips(Sex.values, _sex, (s) => s.label, (v) => _sex = v),
        _label('Obiettivo'),
        _chips(Goal.values, _goal, (g) => g.label, (v) => _goal = v),
        _label('Livello di attività'),
        _chips(Activity.values, _activity, (a) => a.label, (v) => _activity = v),
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(_activity.hint, style: Theme.of(context).textTheme.bodySmall),
        ),
        _label('Giorni di allenamento a settimana: ${_days.round()}'),
        Slider(
          value: _days,
          min: 1,
          max: 6,
          divisions: 5,
          label: '${_days.round()}',
          onChanged: (v) => setState(() => _days = v),
        ),
        _label('Preferenze o esclusioni alimentari'),
        TextFormField(
          controller: _prefs,
          minLines: 2,
          maxLines: 3,
          decoration: const InputDecoration(
              hintText: 'es. vegetariano, senza lattosio, no pesce, allergia alle arachidi'),
        ),
        const SizedBox(height: 28),
        FilledButton(onPressed: _submit, child: Text(widget.submitLabel)),
      ]),
    );
  }
}
