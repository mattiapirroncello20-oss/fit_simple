import 'dart:math';
import 'package:flutter/material.dart';
import '../core/models.dart';

/// Card minimal: nessuna ombra, angoli morbidi.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(20),
        ),
        child: child,
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 24, 4, 10),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w600)),
      );
}

/// Avviso obbligatorio: i consigli non sostituiscono medico o nutrizionista.
class Disclaimer extends StatelessWidget {
  const Disclaimer({super.key});
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme.onSurfaceVariant;
    return Padding(
      padding: const EdgeInsets.only(top: 24),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.info_outline, size: 16, color: c),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            'I consigli di questa app sono indicativi e non sostituiscono il parere '
            'di un medico o di un nutrizionista. In caso di patologie, gravidanza o '
            'dubbi, consultali prima di cambiare dieta o allenamento.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: c),
          ),
        ),
      ]),
    );
  }
}

/// Anello di progresso dei passi. Si anima solo quando il valore cambia.
class StepRing extends StatelessWidget {
  final int steps, goal;
  const StepRing({super.key, required this.steps, required this.goal});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = Theme.of(context).textTheme;
    final target = goal == 0 ? 0.0 : (steps / goal).clamp(0.0, 1.0);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: target),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) => RepaintBoundary(
        child: SizedBox(
          width: 220,
          height: 220,
          child: CustomPaint(
            painter: _RingPainter(v, cs.primary, cs.surfaceContainerHighest),
            child: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(fmt(steps),
                    style: t.displaySmall?.copyWith(fontWeight: FontWeight.w700)),
                Text('passi', style: t.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
                const SizedBox(height: 4),
                Text('${(target * 100).round()}% dell\'obiettivo',
                    style: t.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double progress;
  final Color color, track;
  _RingPainter(this.progress, this.color, this.track);

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2 - 12;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = track;
    canvas.drawCircle(center, radius, p);
    p.color = color;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -pi / 2,
        2 * pi * progress, false, p);
  }

  @override
  bool shouldRepaint(_RingPainter o) =>
      o.progress != progress || o.color != color || o.track != track;
}
