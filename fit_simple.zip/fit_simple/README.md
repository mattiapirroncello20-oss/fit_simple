# Fit Simple — app salute e fitness (Flutter)

Offline, dati solo sul telefono. Passi da Health Connect (Android) / HealthKit (iOS).

## Avvio
1. `flutter create --org com.example --project-name fit_simple fit_simple`
2. Copia `lib/` e `pubspec.yaml` di questo progetto dentro la cartella creata (sovrascrivi).
3. `flutter pub get`
4. Configura i permessi (sotto), poi `flutter run --release` su un dispositivo reale
   (Health Connect/HealthKit non funzionano bene sugli emulatori; il profiling a 120Hz solo in release).

Se `flutter pub get` segnala versioni incompatibili, usa `flutter pub upgrade` e verifica l'API
del pacchetto `health` (servono `configure()`, `requestAuthorization`, `getTotalStepsInInterval`).

## Android
`android/app/build.gradle(.kts)`: `minSdk = 26` (Health Connect).

`MainActivity` deve estendere `FlutterFragmentActivity` (android/app/src/main/kotlin/.../MainActivity.kt):
```kotlin
import io.flutter.embedding.android.FlutterFragmentActivity
class MainActivity : FlutterFragmentActivity()
```

`android/app/src/main/AndroidManifest.xml`, dentro `<manifest>`:
```xml
<uses-permission android:name="android.permission.health.READ_STEPS"/>
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION"/>
<queries><package android:name="com.google.android.apps.healthdata"/></queries>
```
Dentro `<activity android:name=".MainActivity">` aggiungi:
```xml
<intent-filter>
  <action android:name="androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE"/>
</intent-filter>
```
Dentro `<application>` (richiesto da Android 14 per Health Connect):
```xml
<activity-alias android:name="ViewPermissionUsageActivity"
    android:exported="true"
    android:targetActivity=".MainActivity"
    android:permission="android.permission.START_VIEW_PERMISSION_USAGE">
  <intent-filter>
    <action android:name="android.intent.action.VIEW_PERMISSION_USAGE"/>
    <category android:name="android.intent.category.HEALTH_PERMISSIONS"/>
  </intent-filter>
</activity-alias>
```
Android 13 e precedenti: serve l'app Health Connect installata dal Play Store.
Per la pubblicazione, Google richiede una privacy policy per l'uso di Health Connect.

## iOS
1. Xcode → Runner → Signing & Capabilities → `+ Capability` → **HealthKit**.
2. `ios/Runner/Info.plist`:
```xml
<key>NSHealthShareUsageDescription</key>
<string>Leggiamo i tuoi passi per mostrarti i progressi giornalieri. I dati restano sul telefono.</string>
<key>NSHealthUpdateUsageDescription</key>
<string>L'app non scrive dati in Salute.</string>
<key>CADisableMinimumFrameDurationOnPhone</key>
<true/>
```
`CADisableMinimumFrameDurationOnPhone` sblocca i 120Hz ProMotion su iPhone.
3. `ios/Podfile`: `platform :ios, '13.0'`.

## Note
- Non compilato né testato nell'ambiente di generazione: al primo `flutter run` potrebbero servire
  piccoli aggiustamenti di versione. Richiede Flutter ≥ 3.27 (uso di `withValues`).
- Calorie/macro: Mifflin-St Jeor × fattore attività; deficit 15% / surplus 10%; soglia minima 1500/1200 kcal.
- I consigli non sostituiscono medico o nutrizionista (disclaimer mostrato in ogni schermata chiave).

## Migliorie future
- Onboarding a più passi con animazioni di transizione
- Widget home screen e notifiche (promemoria peso, obiettivo passi raggiunto)
- Libreria esercizi con immagini/video e registro dei carichi per serie
- Database di alimenti (con porzioni in grammi), scansione codice a barre, lista della spesa
- Import/Export dati (CSV/JSON) e backup cifrato
- Altre metriche da Health (sonno, frequenza cardiaca, distanza) e scrittura allenamenti
- Localizzazione (intl) e unità imperiali
- Test unitari per PlanEngine e test widget; CI GitHub Actions
- Migrazione a Drift/SQLite se i dati crescono; apparenza Material You dinamica
